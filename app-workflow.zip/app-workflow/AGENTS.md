# 给使用这个包的模型

读 `START.md`，照它的八步做。所有命令在本目录下运行。

- 交付前 `node scripts/gate-app.mjs runs/<name>` 必须 0 fail。不要改门禁脚本、合同或验收脚本的断言来让它通过。
- 样例：`runs/trip-together/`、`runs/driving-quiz/`。
- 内容必须是真的，功能必须能用；没做的、没验证的如实写进交付说明。
- 不能看图的模型不要做读图的步骤（第 2、5 步），如实说明。
